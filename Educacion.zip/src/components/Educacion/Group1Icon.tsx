import { memo, SVGProps } from 'react';

const Group1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1590 234' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={161} cy={142.444} rx={161} ry={83.1508} fill='#4195D1' />
    <ellipse cx={357} cy={107.623} rx={161} ry={83.1508} fill='#4195D1' />
    <ellipse cx={571} cy={142.444} rx={161} ry={83.1508} fill='#4195D1' />
    <ellipse cx={769} cy={83.6081} rx={161} ry={83.1508} fill='#4195D1' />
    <ellipse cx={843} cy={150.849} rx={161} ry={83.1508} fill='#4195D1' />
    <ellipse cx={1075} cy={83.6081} rx={161} ry={83.1508} fill='#4195D1' />
    <ellipse cx={1236} cy={128.035} rx={161} ry={83.1508} fill='#4195D1' />
    <ellipse cx={1429} cy={99.2177} rx={161} ry={83.1508} fill='#4195D1' />
  </svg>
);

const Memo = memo(Group1Icon);
export { Memo as Group1Icon };
