import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Educacion.module.css';
import { Group1Icon } from './Group1Icon.js';

interface Props {
  className?: string;
}
/* @figmaId 8:765 */
export const Educacion: FC<Props> = memo(function Educacion(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.rectangle1}></div>
      <div className={classes.group1}>
        <Group1Icon className={classes.icon} />
      </div>
      <div className={classes.frame1}>
        <div className={classes.image2}></div>
      </div>
      <div className={classes.area}>Área</div>
      <div className={classes.aTENEOSYSUPERVISIONESCLINICAS}>
        <div className={classes.textBlock}>ATENEOS Y SUPERVISIONES CLÍNICAS</div>
        <div className={classes.textBlock2}>
          <p></p>
        </div>
      </div>
      <div className={classes.aREATieneUnaLargaTrayectoriaEn}>
        <div className={classes.textBlock3}>
          ÁREA tiene una larga trayectoria en la supervisión e intercambio clínico con otros colegas.
        </div>
        <div className={classes.textBlock4}>
          <p></p>
        </div>
        <div className={classes.textBlock5}>
          Ofrecemos la posibilidad de realizar supervisiones y ateneos clínicos tanto presenciales como virtuales.
        </div>
        <div className={classes.textBlock6}>
          Las supervisiones pueden realizarse tanto con alguno de los equipos de nuestra institución como con uno de sus
          miembros en particular. 
        </div>
        <div className={classes.textBlock7}>
          <p></p>
        </div>
        <div className={classes.textBlock8}>
          <p className={classes.labelWrapper}>
            <span className={classes.label}>Para solicitar alguno de estos dispositivos complete sus datos en </span>
            <a
              className={classes.label2}
              href='https://areatrastornosbipolares.com/contacto/'
              target='_blank'
              rel='noreferrer'
            >
              aquí
            </a>
            <span className={classes.label3}> y nos comunicaremos con Usted a la brevedad.  </span>
          </p>
        </div>
      </div>
      <div className={classes.line1}></div>
      <div className={classes.image4}></div>
      <div className={classes.unaFormaDeBrindarApoyoClinicoY}>
        Una forma de brindar apoyo clínico y académico a aquellos colegas que  lo requieran con modalidad presencia o
        virtual sorteando las distancias a las que se encuentren.
      </div>
      <div className={classes.materialEnVideo}>Material en video</div>
      <div className={classes.line6}></div>
      <div className={classes.line4}></div>
      <div className={classes.line5}></div>
      <div className={classes.rectangle33}></div>
      <div className={classes.rectangle34}></div>
      <div className={classes.rectangle35}></div>
      <div className={classes.rectangle36}></div>
      <div className={classes.rectangle37}></div>
      <div className={classes.rectangle38}></div>
      <div className={classes.papersDelMes}>Papers del mes</div>
      <div className={classes.line2}></div>
      <div className={classes.rectangle21}></div>
      <div className={classes.rectangle25}></div>
      <div className={classes.rectangle26}></div>
      <div className={classes.rectangle27}></div>
      <div className={classes.rectangle28}></div>
      <div className={classes.rectangle29}></div>
      <div className={classes.rectangle30}></div>
      <div className={classes.rectangle31}></div>
      <div className={classes.rectangle32}></div>
      <div className={classes.rectangle22}></div>
      <div className={classes.rectangle23}></div>
      <div className={classes.rectangle24}></div>
      <div className={classes.enero}>Enero</div>
      <div className={classes.abril}>Abril</div>
      <div className={classes.julio}>Julio</div>
      <div className={classes.octubre}>Octubre</div>
      <div className={classes.noviembre}>Noviembre</div>
      <div className={classes.diciembre}>Diciembre</div>
      <div className={classes.agosto}>Agosto</div>
      <div className={classes.septiembre}>Septiembre</div>
      <div className={classes.mayo}>Mayo</div>
      <div className={classes.junio}>Junio</div>
      <div className={classes.febrero}>Febrero</div>
      <div className={classes.marzo}>Marzo</div>
    </div>
  );
});
