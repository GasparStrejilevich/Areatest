import { memo, SVGProps } from 'react';

const BolasMedioIcon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 2030 1930' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect x={126} y={161} width={1816} height={1769} fill='#4195D1' />
    <ellipse cx={344.247} cy={1424.61} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={575.463} cy={1346.5} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={827.913} cy={1424.61} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1061.49} cy={1292.62} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1148.78} cy={1443.47} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1422.47} cy={1292.62} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1612.4} cy={1392.29} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1840.07} cy={1327.64} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={189.927} cy={318.521} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={421.143} cy={240.406} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={673.594} cy={318.521} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={907.169} cy={186.533} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={994.465} cy={337.376} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1268.15} cy={186.533} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1458.08} cy={286.198} rx={189.927} ry={186.533} fill='#4195D1' />
    <ellipse cx={1685.75} cy={221.551} rx={189.927} ry={186.533} fill='#4195D1' />
  </svg>
);

const Memo = memo(BolasMedioIcon2);
export { Memo as BolasMedioIcon2 };
