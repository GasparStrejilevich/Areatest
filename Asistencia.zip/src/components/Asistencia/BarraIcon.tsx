import { memo, SVGProps } from 'react';

const BarraIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1590 615' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g filter='url(#filter0_d_44_188)'>
      <rect x={75} width={1440} height={505.642} fill='#4195D1' />
      <ellipse cx={161} cy={529.035} rx={161} ry={78.0729} fill='#4195D1' />
      <ellipse cx={357} cy={496.341} rx={161} ry={78.0729} fill='#4195D1' />
      <ellipse cx={571} cy={529.035} rx={161} ry={78.0729} fill='#4195D1' />
      <ellipse cx={769} cy={473.792} rx={161} ry={78.0729} fill='#4195D1' />
      <ellipse cx={843} cy={536.927} rx={161} ry={78.0729} fill='#4195D1' />
      <ellipse cx={1075} cy={473.792} rx={161} ry={78.0729} fill='#4195D1' />
      <ellipse cx={1236} cy={515.506} rx={161} ry={78.0729} fill='#4195D1' />
      <ellipse cx={1429} cy={488.449} rx={161} ry={78.0729} fill='#4195D1' />
    </g>
    <defs>
      <filter
        id='filter0_d_44_188'
        x={-171.3}
        y={-167.3}
        width={1932.6}
        height={957.6}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feColorMatrix
          in='SourceAlpha'
          type='matrix'
          values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0'
          result='hardAlpha'
        />
        <feOffset dy={4} />
        <feGaussianBlur stdDeviation={85.65} />
        <feComposite in2='hardAlpha' operator='out' />
        <feColorMatrix type='matrix' values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0' />
        <feBlend mode='normal' in2='BackgroundImageFix' result='effect1_dropShadow_44_188' />
        <feBlend mode='normal' in='SourceGraphic' in2='effect1_dropShadow_44_188' result='shape' />
      </filter>
    </defs>
  </svg>
);

const Memo = memo(BarraIcon);
export { Memo as BarraIcon };
