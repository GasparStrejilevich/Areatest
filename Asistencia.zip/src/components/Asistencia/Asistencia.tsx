import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Asistencia.module.css';
import { BarraIcon } from './BarraIcon.js';
import { BolasMedioIcon2 } from './BolasMedioIcon2.js';
import { BolasMedioIcon } from './BolasMedioIcon.js';

interface Props {
  className?: string;
}
/* @figmaId 8:642 */
export const Asistencia: FC<Props> = memo(function Asistencia(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.bolasMedio}>
        <BolasMedioIcon className={classes.icon} />
      </div>
      <div className={classes.gruposPsicoeducativosParaPacie}>
        <div className={classes.textBlock}>Grupos psicoeducativos para pacientes y familiares</div>
        <div className={classes.textBlock2}>
          <p></p>
        </div>
      </div>
      <div className={classes.QueSonLosGruposPsicoeducativos}>¿Que son los grupos psicoeducativos?</div>
      <div className={classes.laPsicoeducacionEsUnaTecnicaPs}>
        <div className={classes.textBlock3}>
          La psicoeducación es una técnica psicoterapéutica  que ha probado eficacia en el tratamiento de los Trastornos
          Bipolares.
        </div>
        <div className={classes.textBlock4}>
          La misma se desarrolla de forma grupal, en encuentros que están dirigidos a pacientes o sus familiares.
        </div>
        <div className={classes.textBlock5}>
          <p></p>
        </div>
        <div className={classes.textBlock6}>
          Estos tratamientos han demostrado reducir de manera significativa la severidad de los trastornos anímicos. 
        </div>
        <div className={classes.textBlock7}>
          <p></p>
        </div>
        <div className={classes.textBlock8}>
          Los encuentros son coordinados por profesionales y de acuerdo a un programa pre-establecido. Durante los
          mismos se informa y entrena sobre aquellos aspectos de la enfermedad que luego permiten identificar
          tempranamente los episodios y manejarlos de una mejor manera.
        </div>
        <div className={classes.textBlock9}>
          <p className={classes.labelWrapper}></p>
        </div>
        <a
          href='https://areatrastornosbipolares.com/trastornos-bipolares-educacion/'
          target='_blank'
          rel='noreferrer'
          className={classes.textBlock10}
        >
          <p></p>
        </a>
      </div>
      <div className={classes.rectangle14}></div>
      <div className={classes.line3}></div>
      <div className={classes.bArra}>
        <BarraIcon className={classes.icon2} />
      </div>
      <div className={classes.psiquiatria}>Psiquiatria</div>
      <div className={classes.QueEsLaPsiquiatria}>¿Que es la psiquiatria?</div>
      <div className={classes.laPsiquiatriaEsLaRamaDeLaMedic}>
        <div className={classes.textBlock11}>
          La Psiquiatría es la rama de la medicina que se ocupa de las enfermedades del Sistema Nervioso Central que
          producen síntomas que alteran la conducta y el modo en que comprendemos nuestro entorno y tomamos decisiones.
        </div>
        <div className={classes.textBlock12}>
          <p></p>
        </div>
        <div className={classes.textBlock13}>
          En los últimos 20 años, esta especialidad ha experimentado enormes progresos, especialmente en el desarrollo
          de tratamientos efectivos para el tratamiento de los trastornos del ánimo. Estos tratamiento se administran a
          través de protocolos que están basados en la evidencia científica y son establecidos a través de consensos
          internacionales.
        </div>
      </div>
      <div className={classes.rectangle12}></div>
      <div className={classes.line1}></div>
      <div className={classes.psicoterapia}>Psicoterapia</div>
      <div className={classes.QueEsLaPsicoterapia}>¿Que es la psicoterapia?</div>
      <div className={classes.lasPsicoterapiasSonParteEsenci}>
        <div className={classes.textBlock14}>
          Las Psicoterapias son parte esencial del tratamiento de los trastornos del ánimo. Desde hace varios existen
          psicoterapias específicas que han demostrado efectividad en el tratamiento de estas patologías. Cada uno de
          estos tratamientos debe ser indicado en el tipo de trastorno anímico y el momento adecuado.
        </div>
        <div className={classes.textBlock15}>
          <p></p>
        </div>
        <div className={classes.textBlock16}>
          Técnicas como la Terapia Cognitiva, Mindfulness, DBT o ACT han demostrado ser eficaces para algunas
          indicaciones  pero para otras no. Por esta razón, es indispensable que estos tratamientos sean dirigidos por
          un equipo psicoterapéutico entrenado y con experiencia en estas patologías.
        </div>
      </div>
      <div className={classes.rectangle13}></div>
      <div className={classes.line2}></div>
      <div className={classes.bolasMedio2}>
        <BolasMedioIcon2 className={classes.icon3} />
      </div>
      <div className={classes.talleres}>Talleres</div>
      <div className={classes.programasDePsicoeducacion}>Programas de Psicoeducacion</div>
      <div className={classes.talleresPsicoeducativosParaFam}>
        Talleres psicoeducativos para familiares de personas afectadas por trastorno bipolar
      </div>
      <div className={classes.losMismosConsistenEn6Encuentro}>
        <div className={classes.textBlock17}>
          Los mismos consisten en 6 encuentros semanales de una hora y media de duración aproximadamente. La modalidad
          es grupal y pueden asistir familiares y allegados de personas afectadas por Trastornos Bipolares.
        </div>
        <div className={classes.textBlock18}>
          <p></p>
        </div>
        <div className={classes.textBlock19}>
          <p className={classes.labelWrapper2}>
            <span className={classes.label}>
              Si desea más información o participar en este tratamiento complete sus datos haciendo clic 
            </span>
            <a
              className={classes.label2}
              href='https://areatrastornosbipolares.com/contacto/'
              target='_blank'
              rel='noreferrer'
            >
              aquí
            </a>
            <span className={classes.label3}> y nos comunicaremos con Usted. </span>
          </p>
        </div>
      </div>
      <div className={classes.talleresPsicoeducativosParaPer}>
        <div className={classes.textBlock20}>
          Talleres psicoeducativos para personas afectadas por trastornos bipolares
        </div>
        <div className={classes.textBlock21}>
          <p></p>
        </div>
      </div>
      <div className={classes.losMismosConsistenEn16Encuentr}>
        <div className={classes.textBlock22}>
          Los mismos consisten en 16 encuentros semanales de una hora y media de duración aproximadamente. Los mismos
          están destinados a personas afectados por trastorno bipolar, que se encuentren en tratamiento y estén estables
          desde hace al menos dos meses.
        </div>
        <div className={classes.textBlock23}>
          <p></p>
        </div>
        <div className={classes.textBlock24}>
          <p className={classes.labelWrapper3}>
            <span className={classes.label4}>
              Si desea más información o participar en este tratamiento complete sus datos haciendo clic 
            </span>
            <a
              className={classes.label5}
              href='https://areatrastornosbipolares.com/contacto/'
              target='_blank'
              rel='noreferrer'
            >
              aquí
            </a>
            <span className={classes.label6}> y nos comunicaremos con Usted. </span>
          </p>
        </div>
      </div>
      <div className={classes.QueSonLosGruposPsicoeducativos2}>¿Que son los grupos psicoeducativos?</div>
      <div className={classes.psicoeducacion}>Psicoeducación</div>
      <div className={classes.losCursosDePsicoeducacionSonUn}>
        <div className={classes.textBlock25}>
          Los cursos de psicoeducación son un verdadero entrenamiento para el manejo de los trastornos anímicos. En cada
          encuentro se provee información sobre alguno de los aspectos de la enfermedad. El objetivo es que, finalizado
          el grupo, los participantes sean capaces de identificar tempranamente sus episodios y puedan manejarlos mejor,
          lo que ayuda también a evitar nuevas recaídas.
        </div>
        <div className={classes.textBlock26}>
          Estudios clínicos han demostrado que Las personas que realizan este tratamiento sufren menos episodios
          anímicos  y pasan menos tiempo padeciendo síntomas de estos desórdenes.
        </div>
        <div className={classes.textBlock27}>
          La psicoeducación no es una terapia de grupo en donde uno cuenta sus problemas. Tampoco son grupos de
          autoayuda. Se desarrolla en forma grupal, en encuentros semanales de hora y media de duración. Las reuniones
          son coordinadas por dos profesionales entrenados a tal efecto.
        </div>
      </div>
      <div className={classes.rectangle15}></div>
      <div className={classes.line6}></div>
      <div className={classes.line4}></div>
      <div className={classes.line9}></div>
      <div className={classes.line8}></div>
      <div className={classes.frame1}>
        <div className={classes.image2}></div>
      </div>
      <div className={classes.area}>Área</div>
    </div>
  );
});
