import { memo, SVGProps } from 'react';

const Book1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 55 56' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M27.5 14.098C23.7224 10.6478 18.8247 8.74287 13.75 8.75C11.3392 8.75 9.02458 9.17 6.875 9.94467V43.1947C9.0833 42.4014 11.4083 41.9974 13.75 42C19.0323 42 23.8517 44.023 27.5 47.348M27.5 14.098C31.2774 10.6476 36.1753 8.74264 41.25 8.75C43.6608 8.75 45.9754 9.17 48.125 9.94467V43.1947C45.9167 42.4014 43.5917 41.9974 41.25 42C36.1753 41.9929 31.2776 43.8978 27.5 47.348M27.5 14.098V47.348'
      stroke='white'
      strokeWidth={4}
      strokeLinecap='round'
      strokeLinejoin='round'
    />
  </svg>
);

const Memo = memo(Book1Icon);
export { Memo as Book1Icon };
