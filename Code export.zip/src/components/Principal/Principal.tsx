import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Arrow_down1Icon } from './Arrow_down1Icon.js';
import { BolasIcon } from './BolasIcon.js';
import { BolasMedioIcon } from './BolasMedioIcon.js';
import { Book1Icon } from './Book1Icon.js';
import { Contactanos_Property1Default2 } from './Contactanos_Property1Default2/Contactanos_Property1Default2.js';
import { Contactanos_Property1Default } from './Contactanos_Property1Default/Contactanos_Property1Default.js';
import { Facebook1Icon } from './Facebook1Icon.js';
import { Facebook2Icon } from './Facebook2Icon.js';
import { Group3Icon2 } from './Group3Icon2.js';
import { Group3Icon } from './Group3Icon.js';
import { Group4Icon2 } from './Group4Icon2.js';
import { Group4Icon } from './Group4Icon.js';
import { Instagram1Icon } from './Instagram1Icon.js';
import { Mail1Icon } from './Mail1Icon.js';
import { Papeles1Icon } from './Papeles1Icon.js';
import { Peri_Property1Default } from './Peri_Property1Default/Peri_Property1Default.js';
import { Person1Icon } from './Person1Icon.js';
import classes from './Principal.module.css';
import { Psicologos_Property1Default } from './Psicologos_Property1Default/Psicologos_Property1Default.js';
import { Psiquiatras_Property1Default } from './Psiquiatras_Property1Default/Psiquiatras_Property1Default.js';
import { Telefono1Icon } from './Telefono1Icon.js';
import { Trastorno_Property1Default } from './Trastorno_Property1Default/Trastorno_Property1Default.js';
import { Video1Icon } from './Video1Icon.js';
import { World1Icon } from './World1Icon.js';

interface Props {
  className?: string;
}
/* @figmaId 1:2 */
export const Principal: FC<Props> = memo(function Principal(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.bajo}></div>
      <div className={classes.group3}>
        <Group3Icon className={classes.icon2} />
      </div>
      <div className={classes.group4}>
        <Group4Icon className={classes.icon3} />
      </div>
      <div className={classes._2024TrastornosBipolaresAREATod}>
        © 2024 Trastornos Bipolares | AREA. Todos los derechos reservados.
      </div>
      <div className={classes.rectangle7}></div>
      <div className={classes.rectangle8}></div>
      <div className={classes.rectangle9}></div>
      <div className={classes.nombreCompleto}>Nombre completo</div>
      <div className={classes.nombreTelefono}>Nombre telefono</div>
      <div className={classes.email}>Email</div>
      <div className={classes.envianosTuMensaje}>Envianos tu mensaje</div>
      <div className={classes.nombreYApellido}>Nombre y apellido</div>
      <div className={classes.numeroDeContacto}>Numero de contacto</div>
      <div className={classes.email2}>Email</div>
      <Contactanos_Property1Default
        className={classes.contactanos2}
        text={{
          contactanos: <div className={classes.contactanos}>Enviar</div>,
        }}
      />
      <div className={classes.rectangle10}></div>
      <div className={classes.contactanos15}>Contactanos</div>
      <div className={classes.mail1}>
        <Mail1Icon className={classes.icon4} />
      </div>
      <div className={classes.infoAreatrastornosbipolaresCom}>info@areatrastornosbipolares.com</div>
      <div className={classes.telefono1}>
        <Telefono1Icon className={classes.icon5} />
      </div>
      <div className={classes._541148064997}>(5411) 4806-4997</div>
      <div className={classes.aREATrastornosdelAnimo}>
        <a
          href='https://www.facebook.com/AREA.TrastornosdelAnimo'
          target='_blank'
          rel='noreferrer'
          className={classes.textBlock}
        >
          AREA.TrastornosdelAnimo
        </a>
      </div>
      <div className={classes.Area_trastornos_del_animo}>
        <a
          href='https://www.instagram.com/area_trastornos_del_animo/#'
          target='_blank'
          rel='noreferrer'
          className={classes.textBlock2}
        >
          @area_trastornos_del_animo
        </a>
      </div>
      <div className={classes.instagram1}>
        <Instagram1Icon className={classes.icon6} />
      </div>
      <div className={classes.facebook1}>
        <Facebook1Icon className={classes.icon7} />
      </div>
      <div className={classes.facebook2}>
        <Facebook2Icon className={classes.icon8} />
      </div>
      <div className={classes.bolas}>
        <BolasIcon className={classes.icon9} />
      </div>
      <div className={classes.barra}></div>
      <div className={classes.frame1}>
        <div className={classes.image2}></div>
      </div>
      <div className={classes.area}>Área</div>
      <div className={classes.blog}>Blog</div>
      <div className={classes.masInfo}>Mas info</div>
      <div className={classes.quienesSomos}>Quienes somos</div>
      <div className={classes.equipo}>Equipo</div>
      <div className={classes.investigacion}>Investigación</div>
      <div className={classes.educacion}>Educacion</div>
      <Contactanos_Property1Default
        className={classes.contactanos4}
        text={{
          contactanos: <div className={classes.contactanos3}>Contactanos</div>,
        }}
      />
      <Trastorno_Property1Default
        className={classes.trastorno}
        text={{
          trastornosDelAnimo: <div className={classes.trastornosDelAnimo}>Trastornos del animo</div>,
        }}
      />
      <Contactanos_Property1Default
        className={classes.contactanos6}
        text={{
          contactanos: <div className={classes.contactanos5}>Turnos/info</div>,
        }}
      />
      <div className={classes.aREAFueCreadaEn2003ConElObjeti}>
        <div className={classes.textBlock3}>
          ÁREA fue creada en 2003 con el objetivo de brindar asistencia interdisciplinaria a personas afectadas por
          Trastornos del Ánimo.
        </div>
        <ul className={classes.list}>
          <li>
            <div className={classes.textBlock4}>
              Además ÁREA es un centro de investigación dedicado al estudio de los Trastornos del Ánimo que hoy en día
              es referencia académica en nuestra región.
            </div>
          </li>
        </ul>
        <ul className={classes.list2}>
          <li>
            <div className={classes.textBlock5}>
              <p className={classes.labelWrapper}>
                <span className={classes.label}>
                  Nuestro compromiso está orientado a lograr una medicina ética, equitativa y accesible.
                </span>
              </p>
            </div>
          </li>
          <li>
            <div className={classes.textBlock6}>
              Nuestra práctica se basa en brindar asistencia psiquiátrica y psicológica basada en la evidencia y bajo
              guías consensuadas internacionalmente.
            </div>
          </li>
          <li>
            <div className={classes.textBlock7}>
              Nuestro nivel académico está basado en el entrenamiento y la actualización que demanda pertenecer a un
              equipo científicamente competitivo internacionalmente.
            </div>
          </li>
        </ul>
      </div>
      <div className={classes.rectangle11}></div>
      <div className={classes.transtornosDelAnimo}>Transtornos del animo</div>
      <div className={classes.lOSTRASTORNOSDELANIMOSONUNGRUP}>
        <div className={classes.textBlock8}>
          LOS TRASTORNOS DEL ÁNIMO SON UN GRUPO DE ENFERMEDADES DEL SISTEMA NERVIOSO.
        </div>
        <div className={classes.textBlock9}>
          <p></p>
        </div>
        <div className={classes.textBlock10}>
          Entre ellos se encuentran los Trastornos Bipolares y los Trastornos Depresivos.
        </div>
      </div>
      <div className={classes.rectangle40}></div>
      <div className={classes.rectangle39}></div>
      <div className={classes.rectangle41}></div>
      <div className={classes.world1}>
        <World1Icon className={classes.icon10} />
      </div>
      <div className={classes.ambosTrastornosHanSidoReconoci}>
        Ambos trastornos han sido reconocidas por la Organización Mundial de la Salud como la causa 1° y 6° de costos
        por enfermedad en el mundo.
      </div>
      <div className={classes.sonSumamenteFrecuentesYAfectan}>
        Son sumamente frecuentes y afectan a personas de todas partes del planeta, sin discrimar por raza, educación,
        nivel económico o cultural. Cualquier persona puede sufrir un trastorno del ánimo.
      </div>
      <div className={classes.actualmenteSeCuentaConSistemas}>
        <div className={classes.textBlock11}>
          Actualmente se cuenta con sistemas de diagnósticos y tratamientos farmacológicos y psicoterapéuticos que han
          demostrado eficacia y pueden significar un enorme alivio para las personas afectadas por trastornos del ánimo.
        </div>
        <div className={classes.textBlock12}>
          <p></p>
        </div>
      </div>
      <div className={classes.book1}>
        <Book1Icon className={classes.icon11} />
      </div>
      <div className={classes.person1}>
        <Person1Icon className={classes.icon12} />
      </div>
      <Contactanos_Property1Default2
        className={classes.contactanos8}
        text={{
          contactanos: <div className={classes.contactanos7}>Saber mas</div>,
        }}
      />
      <div className={classes.group42}>
        <Group4Icon2 className={classes.icon13} />
      </div>
      <div className={classes.group32}>
        <Group3Icon2 className={classes.icon14} />
      </div>
      <div className={classes.bajo2}></div>
      <div className={classes.vIdeo1}>
        <Video1Icon className={classes.icon15} />
      </div>
      <div className={classes.papeles1}>
        <Papeles1Icon className={classes.icon16} />
      </div>
      <div className={classes.masInfo2}>Mas info</div>
      <div className={classes.conocerEsPoder}>Conocer es poder</div>
      <div className={classes.elHechoDeQueUnaPersonaAfectada}>
        <div className={classes.textBlock13}>
          El hecho de que una persona afectada por Trastornos del Ánimo esté adecuadamente informada sobre los mismos,
          ha demostrado ser una parte esencial del tratamientos de estas enfermedades.
        </div>
        <div className={classes.textBlock14}>
          Si bien la principal fuente de acceso a la información debe ser el equipo tratante, es importante contar con
          información accesoria.
        </div>
        <div className={classes.textBlock15}>
          En esta sección encontrará una selección de información en videos y gráfica que consideramos serán de utilidad
          para Usted. 
        </div>
      </div>
      <div className={classes.manualesInstructivosAutoEvalua}>
        <div className={classes.textBlock16}>Manuales, Instructivos, </div>
        <div className={classes.textBlock17}>Auto-evaluaciones, etc.</div>
      </div>
      <div className={classes.videosSobreElTrastornosDelAnim}>
        <div className={classes.textBlock18}>Videos sobre el</div>
        <div className={classes.textBlock19}>Trastornos del Ánimo.</div>
        <div className={classes.textBlock20}>
          <p></p>
        </div>
      </div>
      <div className={classes.nuestroEquipo}>Nuestro equipo</div>
      <div className={classes.direccionGeneralDrSergioStreji}>
        <p className={classes.labelWrapper2}>
          <span className={classes.label2}>Dirección General: Dr. Sergio Strejilevich </span>
          <a
            className={classes.label3}
            href='https://areatrastornosbipolares.com/wp-content/uploads/Biosketch-Strejilevich-Castellano-2019.pdf'
            target='_blank'
            rel='noreferrer'
          >
            (CV)
          </a>
        </p>
      </div>
      <div className={classes.bolasMedio}>
        <BolasMedioIcon className={classes.icon17} />
      </div>
      <div className={classes.QuienesSomos}>¿Quienes somos?</div>
      <div className={classes.aREAEsUnaInstitucionNoGubernam}>
        <div className={classes.textBlock21}>
          ÁREA es una institución no gubernamental cuyo objetivo principal es brindar asistencia interdisciplinaria a
          personas afectadas por Trastornos del Ánimo. Además ÁREA es un centro de investigación dedicado al estudio de
          los Trastornos del Ánimo que hoy en día es referencia académica en nuestra región. 
        </div>
        <ul className={classes.list3}>
          <li>
            <div className={classes.textBlock22}>
              <p></p>
            </div>
          </li>
        </ul>
        <ul className={classes.list4}>
          <li>
            <div className={classes.textBlock23}>
              <p className={classes.labelWrapper3}>
                <span className={classes.label4}>
                  Nuestro compromiso está orientado a lograr una medicina ética, equitativa y accesible.
                </span>
              </p>
            </div>
          </li>
        </ul>
        <div className={classes.textBlock24}>
          <p className={classes.labelWrapper4}></p>
        </div>
        <ul className={classes.list5}>
          <li>
            <div className={classes.textBlock25}>
              <p className={classes.labelWrapper5}>
                <span className={classes.label5}>
                  Nuestra práctica se basa en brindar asistencia psiquiátrica y psicológica basada en la evidencia y
                  bajo guías de tratamiento consensuadas internacionalmente.
                </span>
              </p>
            </div>
          </li>
        </ul>
        <div className={classes.textBlock26}>
          <p className={classes.labelWrapper6}></p>
        </div>
        <ul className={classes.list6}>
          <li>
            <div className={classes.textBlock27}>
              <p className={classes.labelWrapper7}>
                <span className={classes.label6}>
                  Nuestro nivel académico está basado en el entrenamiento y la actualización que demanda pertenecer a un
                  equipo científicamente competitivo internacionalmente
                </span>
              </p>
            </div>
          </li>
        </ul>
      </div>
      <div className={classes.image3}></div>
      <Contactanos_Property1Default2
        className={classes.contactanos10}
        text={{
          contactanos: <div className={classes.contactanos9}>Asistencia</div>,
        }}
      />
      <Psicologos_Property1Default className={classes.psicologos} />
      <Psiquiatras_Property1Default className={classes.psiquiatras} />
      <Peri_Property1Default
        className={classes.peri}
        classes={{ arrow_down1: classes.arrow_down1 }}
        swap={{
          arrow_down1: (
            <div className={classes.arrow_down1}>
              <Arrow_down1Icon className={classes.icon} />
            </div>
          ),
        }}
        text={{
          psiquiatriaPerinatal: <div className={classes.psiquiatriaPerinatal}>Psiquiatría Perinatal</div>,
        }}
      />
      <div className={classes.investigacion2}>Investigacion</div>
      <div className={classes.conozcaNuestroTrabajoYAyudenos}>
        Conozca nuestro trabajo y ayúdenos a saber más sobre los Trastornos del Ánimo
      </div>
      <Contactanos_Property1Default2
        className={classes.contactanos12}
        text={{
          contactanos: <div className={classes.contactanos11}>Contactanos</div>,
        }}
      />
      <Contactanos_Property1Default2
        className={classes.contactanos14}
        text={{
          contactanos: <div className={classes.contactanos13}>Participar</div>,
        }}
      />
    </div>
  );
});
