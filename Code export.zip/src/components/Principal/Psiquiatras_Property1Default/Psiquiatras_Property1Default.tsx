import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { Arrow_down1Icon } from './Arrow_down1Icon.js';
import classes from './Psiquiatras_Property1Default.module.css';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
}
/* @figmaId 8:307 */
export const Psiquiatras_Property1Default: FC<Props> = memo(function Psiquiatras_Property1Default(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.psiquiatras}>Psiquiatras</div>
      <div className={classes.arrow_down1}>
        <Arrow_down1Icon className={classes.icon} />
      </div>
    </div>
  );
});
