import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './Contactanos_Property1Default2.module.css';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
  text?: {
    contactanos?: ReactNode;
  };
}
/* @figmaId 8:620 */
export const Contactanos_Property1Default2: FC<Props> = memo(function Contactanos_Property1Default2(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.rectangle4}></div>
      {props.text?.contactanos != null ? (
        props.text?.contactanos
      ) : (
        <div className={classes.contactanos}>Contactanos</div>
      )}
    </div>
  );
});
