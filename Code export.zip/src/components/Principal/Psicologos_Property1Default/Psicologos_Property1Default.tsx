import { memo } from 'react';
import type { FC } from 'react';

import resets from '../../_resets.module.css';
import { Arrow_down1Icon } from './Arrow_down1Icon.js';
import classes from './Psicologos_Property1Default.module.css';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
}
/* @figmaId 8:347 */
export const Psicologos_Property1Default: FC<Props> = memo(function Psicologos_Property1Default(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.psicologos}>Psicologos</div>
      <div className={classes.arrow_down1}>
        <Arrow_down1Icon className={classes.icon} />
      </div>
    </div>
  );
});
