import { memo, SVGProps } from 'react';

const Arrow_down1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 40 40' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M20.1699 22.9766L29.8324 13.0469C30.5476 12.3125 31.704 12.3125 32.4116 13.0469C33.1192 13.7812 33.1192 14.9687 32.4116 15.7031L21.4633 26.9531C20.771 27.6641 19.6602 27.6797 18.945 27.0078L7.92064 15.7109C7.56305 15.3438 7.38806 14.8594 7.38806 14.3828C7.38806 13.9063 7.56305 13.4219 7.92064 13.0547C8.63581 12.3203 9.79227 12.3203 10.4998 13.0547L20.1699 22.9766Z'
      fill='#4195D1'
    />
  </svg>
);

const Memo = memo(Arrow_down1Icon);
export { Memo as Arrow_down1Icon };
