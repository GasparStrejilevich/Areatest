import { memo, SVGProps } from 'react';

const BolasIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1253 645' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect x={59} width={1134} height={465} fill='#4195D1' />
    <ellipse cx={126.801} cy={524.642} rx={126.801} ry={109.302} fill='#4195D1' />
    <ellipse cx={281.168} cy={478.869} rx={126.801} ry={109.302} fill='#4195D1' />
    <ellipse cx={449.712} cy={524.642} rx={126.801} ry={109.302} fill='#4195D1' />
    <ellipse cx={605.654} cy={447.302} rx={126.801} ry={109.302} fill='#4195D1' />
    <ellipse cx={663.935} cy={535.691} rx={126.801} ry={109.302} fill='#4195D1' />
    <ellipse cx={846.656} cy={447.302} rx={126.801} ry={109.302} fill='#4195D1' />
    <ellipse cx={973.457} cy={505.702} rx={126.801} ry={109.302} fill='#4195D1' />
    <ellipse cx={1125.46} cy={467.821} rx={126.801} ry={109.302} fill='#4195D1' />
  </svg>
);

const Memo = memo(BolasIcon);
export { Memo as BolasIcon };
