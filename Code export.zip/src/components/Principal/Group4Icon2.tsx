import { memo, SVGProps } from 'react';

const Group4Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1615 436' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={184} cy={267.621} rx={184} ry={167.762} fill='#4195D1' />
    <ellipse cx={472} cy={193.952} rx={184} ry={193.952} fill='#4195D1' />
    <ellipse cx={693} cy={267.621} rx={184} ry={167.762} fill='#4195D1' />
    <ellipse cx={831} cy={219.689} rx={184} ry={167.762} fill='#4195D1' />
    <ellipse cx={1109} cy={219.689} rx={184} ry={167.762} fill='#4195D1' />
    <ellipse cx={1293} cy={167.762} rx={184} ry={167.762} fill='#4195D1' />
    <ellipse cx={1431} cy={267.621} rx={184} ry={167.762} fill='#4195D1' />
  </svg>
);

const Memo = memo(Group4Icon2);
export { Memo as Group4Icon2 };
