import { memo, SVGProps } from 'react';

const Group3Icon2 = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1728 378' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={215} cy={211.5} rx={215} ry={166.5} fill='#4195D1' />
    <ellipse cx={585} cy={145.089} rx={184} ry={145.089} fill='#4195D1' />
    <ellipse cx={806} cy={231.452} rx={184} ry={145.089} fill='#4195D1' />
    <ellipse cx={944} cy={189.998} rx={184} ry={145.089} fill='#4195D1' />
    <ellipse cx={1222} cy={189.998} rx={184} ry={145.089} fill='#4195D1' />
    <ellipse cx={1406} cy={145.089} rx={184} ry={145.089} fill='#4195D1' />
    <ellipse cx={1544} cy={231.452} rx={184} ry={145.089} fill='#4195D1' />
  </svg>
);

const Memo = memo(Group3Icon2);
export { Memo as Group3Icon2 };
