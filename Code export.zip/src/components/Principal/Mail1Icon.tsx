import { memo, SVGProps } from 'react';

const Mail1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 64 62' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M54.6665 9.6875H9.3335C6.39987 9.6875 4 12.0123 4 14.8542V47.1458C4 49.9877 6.39987 52.3125 9.3335 52.3125H54.6665C57.6001 52.3125 60 49.9877 60 47.1458V14.8542C60 12.0123 57.6001 9.6875 54.6665 9.6875ZM54 20.6667L32 34.875L10 20.6667V15.5L32 29.7083L54 15.5V20.6667Z'
      fill='white'
    />
  </svg>
);

const Memo = memo(Mail1Icon);
export { Memo as Mail1Icon };
