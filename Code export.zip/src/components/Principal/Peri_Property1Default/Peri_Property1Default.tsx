import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import { Arrow_down1Icon } from './Arrow_down1Icon.js';
import classes from './Peri_Property1Default.module.css';

interface Props {
  className?: string;
  classes?: {
    arrow_down1?: string;
    root?: string;
  };
  swap?: {
    arrow_down1?: ReactNode;
  };
  text?: {
    psiquiatriaPerinatal?: ReactNode;
  };
}
/* @figmaId 8:383 */
export const Peri_Property1Default: FC<Props> = memo(function Peri_Property1Default(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      {props.text?.psiquiatriaPerinatal != null ? (
        props.text?.psiquiatriaPerinatal
      ) : (
        <div className={classes.psiquiatriaPerinatal}>Psiquiatría Perinatal</div>
      )}
      <div className={`${props.classes?.arrow_down1 || ''} ${classes.arrow_down1}`}>
        {props.swap?.arrow_down1 || <Arrow_down1Icon className={classes.icon} />}
      </div>
    </div>
  );
});
