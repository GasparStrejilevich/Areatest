import { memo, SVGProps } from 'react';

const Arrow_down1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 39 40' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M19.4771 22.9766L29.1396 13.0469C29.8548 12.3125 31.0112 12.3125 31.7188 13.0469C32.4264 13.7812 32.4264 14.9687 31.7188 15.7031L20.7705 26.9531C20.0782 27.6641 18.9674 27.6797 18.2522 27.0078L7.22783 15.7109C6.87024 15.3438 6.69525 14.8594 6.69525 14.3828C6.69525 13.9063 6.87024 13.4219 7.22783 13.0547C7.943 12.3203 9.09946 12.3203 9.80703 13.0547L19.4771 22.9766Z'
      fill='#4195D1'
    />
  </svg>
);

const Memo = memo(Arrow_down1Icon);
export { Memo as Arrow_down1Icon };
