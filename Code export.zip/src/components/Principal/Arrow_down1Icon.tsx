import { memo, SVGProps } from 'react';

const Arrow_down1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 34 35' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M17.3954 19.768L25.6329 11.3428C26.2426 10.7197 27.2285 10.7197 27.8317 11.3428C28.4349 11.9659 28.4349 12.9735 27.8317 13.5966L18.4981 23.142C17.9078 23.7453 16.9609 23.7585 16.3512 23.1884L6.95272 13.6032C6.64787 13.2917 6.49869 12.8807 6.49869 12.4763C6.49869 12.072 6.64787 11.661 6.95272 11.3494C7.56242 10.7263 8.54831 10.7263 9.15153 11.3494L17.3954 19.768Z'
      fill='#4195D1'
    />
  </svg>
);

const Memo = memo(Arrow_down1Icon);
export { Memo as Arrow_down1Icon };
