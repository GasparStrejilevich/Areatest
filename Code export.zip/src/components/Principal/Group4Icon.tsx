import { memo, SVGProps } from 'react';

const Group4Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1615 403' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <ellipse cx={184} cy={247.377} rx={184} ry={154.73} fill='#4195D1' />
    <ellipse cx={472} cy={155.276} rx={184} ry={154.73} fill='#4195D1' />
    <ellipse cx={693} cy={247.377} rx={184} ry={154.73} fill='#4195D1' />
    <ellipse cx={831} cy={203.169} rx={184} ry={154.73} fill='#4195D1' />
    <ellipse cx={1109} cy={203.169} rx={184} ry={154.73} fill='#4195D1' />
    <ellipse cx={1293} cy={155.276} rx={184} ry={154.73} fill='#4195D1' />
    <ellipse cx={1431} cy={247.377} rx={184} ry={154.73} fill='#4195D1' />
  </svg>
);

const Memo = memo(Group4Icon);
export { Memo as Group4Icon };
