import { memo } from 'react';
import type { FC, ReactNode } from 'react';

import resets from '../../_resets.module.css';
import classes from './Trastorno_Property1Default.module.css';

interface Props {
  className?: string;
  classes?: {
    root?: string;
  };
  text?: {
    trastornosDelAnimo?: ReactNode;
  };
}
/* @figmaId 8:164 */
export const Trastorno_Property1Default: FC<Props> = memo(function Trastorno_Property1Default(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${props.classes?.root || ''} ${props.className || ''} ${classes.root}`}>
      <div className={classes.rectangle4}></div>
      {props.text?.trastornosDelAnimo != null ? (
        props.text?.trastornosDelAnimo
      ) : (
        <div className={classes.trastornosDelAnimo}>Trastornos del animo</div>
      )}
    </div>
  );
});
