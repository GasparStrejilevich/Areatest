import { memo, SVGProps } from 'react';

const BolasMedioIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1653 553' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect x={138} y={83.81} width={1440} height={385.526} fill='#4195D1' />
    <ellipse cx={224} cy={487.172} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={420} cy={462.244} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={634} cy={487.172} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={832} cy={445.052} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={906} cy={493.19} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={1138} cy={445.052} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={1299} cy={476.857} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={1492} cy={456.227} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={161} cy={101.646} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={357} cy={76.7183} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={571} cy={101.646} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={769} cy={59.5266} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={843} cy={107.664} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={1075} cy={59.5266} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={1236} cy={91.3314} rx={161} ry={59.5266} fill='#4195D1' />
    <ellipse cx={1429} cy={70.7012} rx={161} ry={59.5266} fill='#4195D1' />
  </svg>
);

const Memo = memo(BolasMedioIcon);
export { Memo as BolasMedioIcon };
