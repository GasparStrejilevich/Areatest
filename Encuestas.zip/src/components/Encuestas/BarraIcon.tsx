import { memo, SVGProps } from 'react';

const BarraIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 1590 581' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <g filter='url(#filter0_d_44_136)'>
      <rect x={75} width={1440} height={477.687} fill='#4195D1' />
      <ellipse cx={161} cy={499.788} rx={161} ry={73.7566} fill='#4195D1' />
      <ellipse cx={357} cy={468.901} rx={161} ry={73.7566} fill='#4195D1' />
      <ellipse cx={571} cy={499.788} rx={161} ry={73.7566} fill='#4195D1' />
      <ellipse cx={769} cy={447.599} rx={161} ry={73.7566} fill='#4195D1' />
      <ellipse cx={843} cy={507.243} rx={161} ry={73.7566} fill='#4195D1' />
      <ellipse cx={1075} cy={447.599} rx={161} ry={73.7566} fill='#4195D1' />
      <ellipse cx={1236} cy={487.007} rx={161} ry={73.7566} fill='#4195D1' />
      <ellipse cx={1429} cy={461.445} rx={161} ry={73.7566} fill='#4195D1' />
    </g>
    <defs>
      <filter
        id='filter0_d_44_136'
        x={-171.3}
        y={-167.3}
        width={1932.6}
        height={923.6}
        filterUnits='userSpaceOnUse'
        colorInterpolationFilters='sRGB'
      >
        <feFlood floodOpacity={0} result='BackgroundImageFix' />
        <feColorMatrix
          in='SourceAlpha'
          type='matrix'
          values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0'
          result='hardAlpha'
        />
        <feOffset dy={4} />
        <feGaussianBlur stdDeviation={85.65} />
        <feComposite in2='hardAlpha' operator='out' />
        <feColorMatrix type='matrix' values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0' />
        <feBlend mode='normal' in2='BackgroundImageFix' result='effect1_dropShadow_44_136' />
        <feBlend mode='normal' in='SourceGraphic' in2='effect1_dropShadow_44_136' result='shape' />
      </filter>
    </defs>
  </svg>
);

const Memo = memo(BarraIcon);
export { Memo as BarraIcon };
