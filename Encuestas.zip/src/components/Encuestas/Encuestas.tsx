import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { BarraIcon } from './BarraIcon.js';
import { BolasMedioIcon } from './BolasMedioIcon.js';
import { Contactanos_Property1Default2 } from './Contactanos_Property1Default2/Contactanos_Property1Default2.js';
import { Contactanos_Property1Default } from './Contactanos_Property1Default/Contactanos_Property1Default.js';
import classes from './Encuestas.module.css';

interface Props {
  className?: string;
}
/* @figmaId 8:416 */
export const Encuestas: FC<Props> = memo(function Encuestas(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.bArra}>
        <BarraIcon className={classes.icon} />
      </div>
      <Contactanos_Property1Default
        className={classes.contactanos2}
        text={{
          contactanos: <div className={classes.contactanos}>Participar</div>,
        }}
      />
      <div className={classes.litio}>Litio</div>
      <div className={classes.queremosSaberMasSobreElTratami}>Queremos saber más sobre el tratamiento con Litio</div>
      <div className={classes.UstedHaEstadoOEstaEnTratamient}>
        <div className={classes.textBlock}>¿Usted ha estado o está en tratamiento por padecer Trastorno Bipolar?</div>
        <div className={classes.textBlock2}>
          <p></p>
        </div>
        <div className={classes.textBlock3}>
          Estamos recopilando las experiencias y opiniones sobre el Litio en aquellas personas afectadas por Trastorno
          Bipolar tanto en aquellas que lo han o están tomando como aquellas que no. Conocer las mismas nos ayudará a
          perfeccionar el tratamiento con este medicamento.
        </div>
        <div className={classes.textBlock4}>
          <p></p>
        </div>
        <div className={classes.textBlock5}>Puede ayudarnos participando de esta encuesta anónima online.</div>
      </div>
      <div className={classes.line1}></div>
      <div className={classes.frame9}></div>
      <div className={classes.bolasMedio}>
        <BolasMedioIcon className={classes.icon2} />
      </div>
      <div className={classes.antidepreseivosYLaPsicologia}>Antidepreseivos y la psicologia</div>
      <div className={classes.QueHacenLosAntidepresivosANive}>
        <div className={classes.textBlock6}>¿Qué hacen los antidepresivos a nivel psicológico?</div>
        <div className={classes.textBlock7}>
          <p></p>
        </div>
      </div>
      <div className={classes.ayudenosAInvestigarComoLosAnti}>
        <div className={classes.textBlock8}>
          Ayúdenos a investigar cómo los antidepreivos modifican el procesamiento de nuestras emociones.
        </div>
        <div className={classes.textBlock9}>
          <p></p>
        </div>
      </div>
      <div className={classes.line3}></div>
      <Contactanos_Property1Default
        className={classes.contactanos4}
        text={{
          contactanos: <div className={classes.contactanos3}>Participar</div>,
        }}
      />
      <div className={classes.masTrabajosDeInvestigacionEnCu}>
        <div className={classes.textBlock10}>Mas trabajos de investigación en curso</div>
        <div className={classes.textBlock11}>
          <p></p>
        </div>
      </div>
      <div className={classes.investigacionCualitativaSobreE}>
        <ul className={classes.list}>
          <li>
            <div className={classes.textBlock12}>
              Investigación cualitativa sobre el efecto subjetivo de los fármacos usados en el tratamiento de los
              trastornos afectivos.
            </div>
          </li>
        </ul>
        <div className={classes.textBlock13}>
          <p className={classes.labelWrapper}></p>
        </div>
        <ul className={classes.list2}>
          <li>
            <div className={classes.textBlock14}>
              <p className={classes.labelWrapper2}>
                <span className={classes.label}>
                  Síntomas obseso-compulsivos en personas en tratamiento por trastornos bipolares
                </span>
              </p>
            </div>
          </li>
        </ul>
        <div className={classes.textBlock15}>
          <p className={classes.labelWrapper3}></p>
        </div>
        <ul className={classes.list3}>
          <li>
            <div className={classes.textBlock16}>
              <p className={classes.labelWrapper4}>
                <span className={classes.label2}>
                  Funcionamiento cognitivo en personas afectadas por trastornos bipolar
                </span>
              </p>
            </div>
          </li>
        </ul>
      </div>
      <div className={classes.line4}></div>
      <div className={classes.conozcaAquiLasPublicacionesCie}>
        <a
          href='https://areatrastornosbipolares.com/lista-de-publicaciones/'
          target='_blank'
          rel='noreferrer'
          className={classes.textBlock17}
        >
          Conozca aquí las publicaciones científicas de ÁREA
        </a>
      </div>
      <Contactanos_Property1Default2
        className={classes.contactanos6}
        text={{
          contactanos: <div className={classes.contactanos5}>Participar</div>,
        }}
      />
      <div className={classes.antidepresivos}>Antidepresivos</div>
      <div className={classes.queremosSaberMasSobreLosAntide}>
        <div className={classes.textBlock18}>Queremos saber más sobre los Antidepresivos</div>
        <div className={classes.textBlock19}>
          <p></p>
        </div>
      </div>
      <div className={classes.siTomoOEstaTomandoAntidepresiv}>
        <div className={classes.textBlock20}>Si tomó o está tomando Antidepresivos…</div>
        <div className={classes.textBlock21}>
          <p></p>
        </div>
        <div className={classes.textBlock22}>
          Nos interesa conocer sus experiencias y opiniones respecto de estos fármacos para poder aprender más sobre
          ellos.
        </div>
        <div className={classes.textBlock23}>
          <p></p>
        </div>
        <div className={classes.textBlock24}>Puede ayudarnos participando de esta encuesta anónima on line. </div>
      </div>
      <div className={classes.line2}></div>
      <Contactanos_Property1Default2
        className={classes.contactanos8}
        text={{
          contactanos: <div className={classes.contactanos7}>Participar</div>,
        }}
      />
      <div className={classes.frame1}>
        <div className={classes.image2}></div>
      </div>
      <div className={classes.area}>Área</div>
    </div>
  );
});
